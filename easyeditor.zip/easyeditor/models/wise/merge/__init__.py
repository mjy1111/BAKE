from .slerp import slerp
from .gta import GTA
from .linear import linear